Vue.component('main-bar',{
       template:'#mainbar', 
       });
new Vue({
   el:'#app',
});
